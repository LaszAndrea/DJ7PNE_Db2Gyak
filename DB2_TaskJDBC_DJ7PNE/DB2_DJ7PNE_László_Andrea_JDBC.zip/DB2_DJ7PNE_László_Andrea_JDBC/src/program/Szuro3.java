package program;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

public class Szuro3 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JButton btnNewButton;
	private JButton btnMents;
	private Met�dusok dbm = new Met�dusok();
	private Szuro3hoz k;

	public Szuro3(SzurokLista sz, Szuro3hoz kk, String min) {

		
		k=kk;
		
		setTitle("Sz�r�s list�ja");
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 925, 435);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(Color.DARK_GRAY);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 889, 300);
		contentPane.add(scrollPane);

		table = new JTable(k);

		scrollPane.setViewportView(table);
		
		btnNewButton = new JButton("Bez�r�s");
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				SzurokLista l = new SzurokLista();
				dispose();
				l.setVisible(true);
				
			}
		});
		btnNewButton.setBounds(474, 344, 101, 30);
		contentPane.add(btnNewButton);
		
		btnMents = new JButton("Ment�s");
		btnMents.setBackground(Color.LIGHT_GRAY);
		btnMents.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dbm.openFile("Szuro3.txt");
				dbm.mentesSzuro3(min);
				dbm.closeFile();
				
			}
		});
		btnMents.setBounds(350, 344, 101, 30);
		contentPane.add(btnMents);
		
	}

}

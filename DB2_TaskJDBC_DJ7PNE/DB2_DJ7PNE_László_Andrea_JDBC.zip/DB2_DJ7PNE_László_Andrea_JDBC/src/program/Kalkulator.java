package program;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Kalkulator {

	public Kalkulator(Belepett b) {
		final JFrame parent = new JFrame();
		parent.setBounds(480, 80, 575, 395);
		parent.setLayout(null);

		parent.setPreferredSize(new Dimension(450, 430));
		parent.setLocation(540, 180);
		parent.setTitle("Kalkul�tor");

		JButton button = new JButton("Darabsz�mot szeretn�k sz�molni kil�b�l");
		JButton button2 = new JButton("Kil�t szeretn�k sz�molni darabsz�mb�l");
		JButton button3 = new JButton("Darabsz�mot szeretn�k sz�molni foly�m�terb�l");
		JButton button4 = new JButton("Foly�m�tert szeretn�k sz�molni darabsz�mb�l");
		
		button.setBounds(50, 50, 350, 40);
		button.setFont(new Font("Tahoma", Font.BOLD, 12));
		parent.add(button, BorderLayout.CENTER);
		
		button2.setBounds(50, 100, 350, 40);
		button2.setFont(new Font("Tahoma", Font.BOLD, 12));
		parent.add(button2, BorderLayout.CENTER);
		
		button3.setBounds(50, 150, 350, 40);
		button3.setFont(new Font("Tahoma", Font.BOLD, 12));
		parent.add(button3, BorderLayout.CENTER);
		
		button4.setBounds(50, 200, 350, 40);
		button4.setFont(new Font("Tahoma", Font.BOLD, 12));
		parent.add(button4, BorderLayout.CENTER);
		
		JButton cancel = new JButton("M�gsem");
		cancel.setBounds(50, 300, 350, 40);
		cancel.setFont(new Font("Tahoma", Font.BOLD, 12));
		parent.add(cancel, BorderLayout.CENTER);
		
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				parent.setVisible(false);
				Login f = new Login();
				Belepett b = new Belepett(f);
				b.setVisible(true);
			}
		});

		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				parent.setVisible(false);
				boolean flag = false;
				int mennyis�g = 0;
				while (!flag) {
					String name2 = JOptionPane.showInputDialog(null, "Adja meg a mennyis�get (kg)");
					if (name2 != null || (name2 != null && ("".equals(name2)))) {
						try {
							mennyis�g = Integer.parseInt(name2);
							flag = false;
							int sz�less�g = 0;
							while (!flag) {
								String name3 = JOptionPane.showInputDialog(parent, "Adja meg a sz�less�get (mm)", null);
								if (name3 != null || (name3 != null && ("".equals(name3)))) {
									try {
										sz�less�g = Integer.parseInt(name3);
										flag = false;
										int vagas = 0;
										String name = JOptionPane.showInputDialog(parent, "Adja meg a v�g�shosszt (mm)",
												null);
										if (name != null || (name != null && ("".equals(name)))) {
											try {
												vagas = Integer.parseInt(name);
												flag = false;
												int grams�ly = 0;
												String name4 = JOptionPane.showInputDialog(parent,
														"Adja meg a grams�lyt (gr/m2)", null);
												if (name4 != null || (name4 != null && ("".equals(name4)))) {
													try {
														grams�ly = Integer.parseInt(name4);
														flag = true;
														Kalkulator tasak = new Kalkulator(mennyis�g, vagas, sz�less�g,
																grams�ly);
														JOptionPane.showMessageDialog(parent,
																"A gy�rtott darabsz�m: " + tasak.szamitas());

													} catch (NumberFormatException ex) {
														JOptionPane.showMessageDialog(parent,
																"User did not enter an integer.");
													}
												} else {
													flag = true;
												}

											} catch (NumberFormatException ex) {
												JOptionPane.showMessageDialog(parent, "User did not enter an integer.");
											}
										} else {
											flag = true;
										}

									} catch (NumberFormatException ex) {
										JOptionPane.showMessageDialog(parent, "User did not enter an integer.");
									}
								} else {
									flag = true;
								}

							}
						} catch (NumberFormatException ex) {
							JOptionPane.showMessageDialog(parent, "User did not enter an integer.");
						}
					} else {
						flag = true;
					}

				}

				parent.setVisible(true);

			}
		});


		parent.pack();
		parent.setVisible(true);
		button2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				parent.setVisible(false);
				boolean flag = false;
				int mennyis�g = 0;
				while (!flag) {
					String name2 = JOptionPane.showInputDialog(null, "Adja meg a mennyis�get (db)");
					if (name2 != null || (name2 != null && ("".equals(name2)))) {
						try {
							mennyis�g = Integer.parseInt(name2);
							flag = false;
							int sz�less�g = 0;
							while (!flag) {
								String name3 = JOptionPane.showInputDialog(parent, "Adja meg a sz�less�get (mm)", null);
								if (name3 != null || (name3 != null && ("".equals(name3)))) {
									try {
										sz�less�g = Integer.parseInt(name3);
										flag = false;
										int vagas = 0;
										String name = JOptionPane.showInputDialog(parent, "Adja meg a v�g�shosszt (mm)",
												null);
										if (name != null || (name != null && ("".equals(name)))) {
											try {
												vagas = Integer.parseInt(name);
												flag = false;
												int grams�ly = 0;
												String name4 = JOptionPane.showInputDialog(parent,
														"Adja meg a grams�lyt (gr/m2)", null);
												if (name4 != null || (name4 != null && ("".equals(name4)))) {
													try {
														grams�ly = Integer.parseInt(name4);
														flag = true;
														Kalkulator tasak = new Kalkulator(mennyis�g, vagas, sz�less�g,
																grams�ly);
														JOptionPane.showMessageDialog(parent,
																"A gy�rtott kil�: " + tasak.szamitas2());

													} catch (NumberFormatException ex) {
														JOptionPane.showMessageDialog(parent,
																"User did not enter an integer.");
													}
												} else {
													flag = true;
												}

											} catch (NumberFormatException ex) {
												JOptionPane.showMessageDialog(parent, "User did not enter an integer.");
											}
										} else {
											flag = true;
										}

									} catch (NumberFormatException ex) {
										JOptionPane.showMessageDialog(parent, "User did not enter an integer.");
									}
								} else {
									flag = true;
								}

							}
						} catch (NumberFormatException ex) {
							JOptionPane.showMessageDialog(parent, "User did not enter an integer.");
						}
					} else {
						flag = true;
					}

				}

				parent.setVisible(true);

			}
		});

		parent.pack();
		parent.setVisible(true);
		button3.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				parent.setVisible(false);
				boolean flag = false;
				int mennyis�g = 0;
				while (!flag) {
					String name2 = JOptionPane.showInputDialog(null, "Adja meg a mennyis�get (fm)");
					if (name2 != null || (name2 != null && ("".equals(name2)))) {
						try {
							mennyis�g = Integer.parseInt(name2);
							flag = false;
							int vagas = 0;
							String name = JOptionPane.showInputDialog(parent, "Adja meg a v�g�shosszt (mm)", null);
							if (name != null || (name != null && ("".equals(name)))) {
								try {
									vagas = Integer.parseInt(name);
									flag = false;
									int palyak = 1;
									String name4 = JOptionPane.showInputDialog(parent, "Adja meg a p�ly�k sz�m�t",
											null);
									if (name4 != null || (name4 != null && ("".equals(name4)))) {
										try {
											palyak = Integer.parseInt(name4);
											Kalkulator tasak = new Kalkulator(mennyis�g, vagas, palyak);
											JOptionPane.showMessageDialog(parent,
													"A gy�rtott mennyis�g (db): " + tasak.szamitas3());
										} catch (NumberFormatException e) {
											JOptionPane.showMessageDialog(parent, "User did not enter an integer.");
										}
									} else {
										flag = true;
									}

								} catch (NumberFormatException e) {
									JOptionPane.showMessageDialog(parent, "User did not enter an integer.");
								}
							} else {
								flag = true;
							}
						} catch (NumberFormatException e) {
							JOptionPane.showMessageDialog(parent, "User did not enter an integer.");
						}
					} else {
						flag = true;
					}
				}
				parent.setVisible(true);
			}
		});

		parent.pack();
		parent.setVisible(true);
		button4.addActionListener(new java.awt.event.ActionListener() {
			@Override
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				parent.setVisible(false);
				boolean flag = false;
				int mennyis�g = 0;
				while (!flag) {
					String name2 = JOptionPane.showInputDialog(null, "Adja meg a mennyis�get (db)");
					if (name2 != null || (name2 != null && ("".equals(name2)))) {
						try {
							mennyis�g = Integer.parseInt(name2);
							flag = false;
							int vagas = 0;
							String name = JOptionPane.showInputDialog(parent, "Adja meg a v�g�shosszt (mm)", null);
							if (name != null || (name != null && ("".equals(name)))) {
								try {
									vagas = Integer.parseInt(name);
									flag = false;
									int palyak = 1;
									String name4 = JOptionPane.showInputDialog(parent, "Adja meg a p�ly�k sz�m�t",
											null);
									if (name4 != null || (name4 != null && ("".equals(name4)))) {
										try {
											palyak = Integer.parseInt(name4);
											Kalkulator tasak = new Kalkulator(mennyis�g, vagas, palyak);
											JOptionPane.showMessageDialog(parent,
													"A gy�rtott mennyis�g (fm): " + tasak.szamitas4());
										} catch (NumberFormatException e) {
											JOptionPane.showMessageDialog(parent, "User did not enter an integer.");
										}
									} else {
										flag = true;
									}

								} catch (NumberFormatException e) {
									JOptionPane.showMessageDialog(parent, "User did not enter an integer.");
								}
							} else {
								flag = true;
							}
						} catch (NumberFormatException e) {
							JOptionPane.showMessageDialog(parent, "User did not enter an integer.");
						}
					} else {
						flag = true;
					}
				}
				parent.setVisible(true);

			}
		});
		
		//JButton p5 = new JButton();
		

	}

	private double mennyiseg;
	private double vagashossz;
	private double szelesseg;
	private double gramsuly;
	private int palyak;

	public Kalkulator(double mennyiseg, double vagashossz, double szelesseg, double gramsuly) {
		super();
		this.mennyiseg = mennyiseg;
		this.vagashossz = vagashossz;
		this.szelesseg = szelesseg;
		this.gramsuly = gramsuly;
	}

	public Kalkulator(double mennyiseg, double vagashossz, int palyak) {
		super();
		this.mennyiseg = mennyiseg;
		this.vagashossz = vagashossz;
		this.palyak = palyak;
	}

	@Override
	public String toString() {
		return "Szamito [mennyiseg=" + mennyiseg + ", vagashossz=" + vagashossz + ", szelesseg=" + szelesseg
				+ ", gramsuly=" + gramsuly + "]";
	}

	public int szamitas() {
		double vegeredmeny;

		vegeredmeny = ((this.mennyiseg)
				/ ((this.vagashossz / 1000) * (this.szelesseg / 1000) * (this.gramsuly / 1000)));
		return (int) vegeredmeny;
	}

	public double szamitas2() {
		double vegeredmeny;

		vegeredmeny = ((this.mennyiseg)
				* ((this.vagashossz / 1000) * (this.szelesseg / 1000) * (this.gramsuly / 1000)));
		return vegeredmeny;
	}

	public double szamitas3() {
		double vegeredmeny;

		vegeredmeny = ((this.mennyiseg) * this.palyak) / (this.vagashossz / 1000);

		return vegeredmeny;
	}

	public double szamitas4() {
		double vegeredmeny;

		vegeredmeny = (this.mennyiseg * (this.vagashossz / 1000)) / this.palyak;

		return vegeredmeny;
	}

}

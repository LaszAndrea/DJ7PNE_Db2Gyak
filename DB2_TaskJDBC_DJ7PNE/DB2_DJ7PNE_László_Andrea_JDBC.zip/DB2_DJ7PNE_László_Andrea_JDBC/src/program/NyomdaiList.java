package program;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableColumn;

public class NyomdaiList extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table = new JTable();
	private Kiolvas�shoz2 k;
	Met�dusok dbm = new Met�dusok();
	private JButton modifyBttn;
	private JButton btnTrls;
	private JButton btnVissza;
	private JButton btnMents;

	public NyomdaiList(JFrame f, Kiolvas�shoz2 kk) {
		
		k=kk;
		
		setTitle("Nyomdaiak list�ja");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1280, 480);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setBackground(Color.DARK_GRAY);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 10, 1244, 300);
		contentPane.add(scrollPane);

		table = new JTable(k);

		scrollPane.setViewportView(table);
		
		modifyBttn = new JButton("M�dos�t�s");
		modifyBttn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int db = 0;
				int sor = 0;
				for (int i = 0; i < k.getRowCount(); i++) {
					if ((Boolean) k.getValueAt(i, 0) == true) {
						db++;
						sor = i;
					}
				}
				if (db == 0)
					error("Nem lett kjel�lve semmi");
				else if (db > 1)
					error("Egyn�l t�bb rekordot nem lehet kijel�lni");
				else if (db == 1) {
					dispose();
					ModositasNyomdai t = new ModositasNyomdai(RTS(sor, 1), RTS(sor, 2), RTS(sor, 3), RTS(sor, 4), RTS(sor, 5),
							RTS(sor, 6), RTS(sor, 7), RTS(sor, 8), RTS(sor, 9),  RTS(sor, 10), RTS(sor, 11));
					t.setVisible(true);
				}
			}
		});
		modifyBttn.setBackground(Color.LIGHT_GRAY);
		modifyBttn.setFont(new Font("Times New Roman", Font.BOLD, 14));
		modifyBttn.setBounds(38, 382, 107, 33);
		contentPane.add(modifyBttn);

		btnTrls = new JButton("T�rl�s");
		btnTrls.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int db = 0;
				for (int i = 0; i < k.getRowCount(); i++) {
					if ((Boolean) k.getValueAt(i, 0) == true) {
						db++;
						dbm.deleteNyomdai(RTS(i, 1));
						k.removeRow(i);
						i--;
						msg("A nyomdai t�r�lve lett!");
					}
				}
				if (db == 0)
					error("Nem lett kjel�lve semmi");

			}
		});
		btnTrls.setBackground(Color.LIGHT_GRAY);
		btnTrls.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnTrls.setBounds(182, 382, 107, 33);
		contentPane.add(btnTrls);

		btnVissza = new JButton("Vissza");
		btnVissza.setBackground(Color.LIGHT_GRAY);
		btnVissza.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				ListSmth n = new ListSmth();
				dispose();
				n.setVisible(true);

			}
		});
		btnVissza.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnVissza.setBounds(1111, 382, 107, 33);
		contentPane.add(btnVissza);
		
		btnMents = new JButton("Ment\u00E9s");
		btnMents.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dbm.openFile("Nyomdai.txt");
				dbm.mentesNyomdai();
				dbm.closeFile();
				
			}
		});
		btnMents.setFont(new Font("Times New Roman", Font.BOLD, 14));
		btnMents.setBackground(Color.LIGHT_GRAY);
		btnMents.setBounds(331, 382, 107, 33);
		contentPane.add(btnMents);

		TableColumn tc = null;
		for (int i = 0; i < 12; i++) {
			tc = table.getColumnModel().getColumn(i);
			if (i == 0) {
				tc.setPreferredWidth(25);
			} else if (i == 1)
			tc.setPreferredWidth(50);
			else if(i==2)
				tc.setPreferredWidth(120);
			else if(i==3)
				tc.setPreferredWidth(140);
			else if (i == 4 || i==5)
				tc.setPreferredWidth(170);
			else if(i==6){
				tc.setPreferredWidth(85);
			}
			else if (i == 8 || i == 7)
				tc.setPreferredWidth(130);
			else if(i == 9 || i == 10)
				tc.setPreferredWidth(105);
			else if(i==11)
				tc.setPreferredWidth(125);
		}
		
	}
	
	public String RTS(int row, int cm) {
		return k.getValueAt(row, cm).toString();
	}
	
	public void msg(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Figyelem!", 2);
	}

	public void error(String msg) {
		JOptionPane.showMessageDialog(null, msg, "Figyelem!", 0);
	}

}
